//
//  TuyaSmartKit.h
//  TuyaSmartKit
//
//  Created by fengyu on 15/9/11.
//  Copyright (c) 2015年 Tuya. All rights reserved.
//

#if __has_include(<TuyaSmartBaseKit/TuyaSmartBaseKit.h>)
    #import <TuyaSmartBaseKit/TuyaSmartBaseKit.h>
#endif

#if __has_include(<TuyaSmartDeviceKit/TuyaSmartDeviceKit.h>)
    #import <TuyaSmartDeviceKit/TuyaSmartDeviceKit.h>
#endif

#if __has_include(<TuyaSmartBLEKit/TuyaSmartBLEKit.h>)
    #import <TuyaSmartBLEKit/TuyaSmartBLEKit.h>
#endif

#if __has_include(<TuyaSmartBLEMeshKit/TuyaSmartBLEMeshKit.h>)
    #import <TuyaSmartBLEMeshKit/TuyaSmartBLEMeshKit.h>
#endif

#if __has_include(<TuyaSmartSceneKit/TuyaSmartSceneKit.h>)
    #import <TuyaSmartSceneKit/TuyaSmartSceneKit.h>
#endif

#if __has_include(<TuyaSmartTimerKit/TuyaSmartTimerKit.h>)
    #import <TuyaSmartTimerKit/TuyaSmartTimerKit.h>
#endif

#if __has_include(<TuyaSmartFeedbackKit/TuyaSmartFeedbackKit.h>)
    #import <TuyaSmartFeedbackKit/TuyaSmartFeedbackKit.h>
#endif

#if __has_include(<TuyaSmartMessageKit/TuyaSmartMessageKit.h>)
    #import <TuyaSmartMessageKit/TuyaSmartMessageKit.h>
#endif
