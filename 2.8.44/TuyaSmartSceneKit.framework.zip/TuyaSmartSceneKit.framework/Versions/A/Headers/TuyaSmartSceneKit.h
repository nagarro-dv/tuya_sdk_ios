//
//  TuyaSmartSceneKit.h
//  TuyaSmartSceneKit
//
//  Created by 高森 on 2018/9/3.
//

#ifndef TuyaSmartSceneKit_h
#define TuyaSmartSceneKit_h

#import <TuyaSmartDeviceKit/TuyaSmartDeviceKit.h>

#import "TuyaSmartScene.h"
#import "TuyaSmartSceneManager.h"

#endif /* TuyaSmartSceneKit_h */
