//
//  TYSafeMutableDictionary.h
//  TYLibraryExample
//
//  Created by 冯晓 on 16/8/23.
//  Copyright © 2016年 Tuya. All rights reserved.
//

#import <Foundation/Foundation.h>

//线程安全的类
@interface TYSDKSafeMutableDictionary : NSMutableDictionary

@end

