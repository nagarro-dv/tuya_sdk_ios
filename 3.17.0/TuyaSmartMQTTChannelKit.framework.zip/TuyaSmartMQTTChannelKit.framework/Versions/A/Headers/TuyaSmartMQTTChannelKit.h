
#ifndef TuyaSmartMQTTChannelKit_h
#define TuyaSmartMQTTChannelKit_h

#import <TuyaSmartBaseKit/TuyaSmartBaseKit.h>

#import "TuyaSmartMQTTChannel.h"
#import "TuyaSmartMQTTConfigModel.h"

#endif
