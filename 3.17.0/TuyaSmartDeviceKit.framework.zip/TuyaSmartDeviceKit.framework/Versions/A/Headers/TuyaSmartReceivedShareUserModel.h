//
//  TuyaSmartReceivedShareUserModel.h
//  TuyaSmartKit
//
//  Created by 冯晓 on 2018/1/9.
//  Copyright © 2018年 Tuya. All rights reserved.
//

@interface TuyaSmartReceivedShareUserModel : NSObject

// user name
@property (nonatomic, strong) NSString *name;

// mobile
@property (nonatomic, strong) NSString *mobile;

// email
@property (nonatomic, strong) NSString *email;


@end
