//
//  CBUUID+TYCategory.h
//  TuyaSmartPublic
//
//  Created by 冯晓 on 16/8/2.
//  Copyright © 2016年 Tuya. All rights reserved.
//

#import <CoreBluetooth/CoreBluetooth.h>

@interface CBUUID (TYCategory)

- (NSString *)tp_CoreBLE_UUID2String;

@end
